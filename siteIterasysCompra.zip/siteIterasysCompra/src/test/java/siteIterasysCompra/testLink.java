// 01 - Pacote = Conjunto de Classes
package siteIterasysCompra;

// 02 - Bibliotecas = Métodos ou Funções prontas

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

// 03 - Classes = Objetos simples ou compostos
public class testLink {
    //3.1 - Atributos = Caracteristicas
    String url; // variavel para o site, que será utilizado para os testes
    WebDriver driver; // motor Selenium WebDriver

    //3.2 - Métodos ou Funcionalidades = O que vai fazer (método executa mas sem retorno)
    @Before
    public void pesquisar(){
        // declarando site para acesso aos testes
        url = "https://iterasys.com.br";

        // ligação do WebDriver (selenium) e o chrome (browser)
        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");

        // Instanciar o objeto Selenium WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize(); // Maximiza a tela
        driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);


    }
    @After
    public void finalizar(){
        driver.quit(); // finalizar(destrui) o objeto Selenium WebDriver
    }

    @Test
    public void consultarTestLink() throws InterruptedException {
        driver.get(url);
        driver.findElement(By.cssSelector("a.cc-btn.cc-dismiss")).click();
        driver.findElement(By.id("searchtext")).sendKeys("Testlink"); // Digita Testlink
        //Thread.sleep(2000);
        //driver.findElement(By.id("searchtext")).sendKeys(Keys.chord("Testlink")); // Soletra Testlink
        driver.findElement(By.id("btn_form_search")).click(); // Clica na lupa de pesquisa
        //Thread.sleep(2000);
        driver.findElement(By.cssSelector("span.comprar")).click(); // Clica no botão MATRICULE-SE

        // Validar nome do curso
        String resultadoEsperado = "TestLink";
        String resultadoAtual = driver.findElement(By.cssSelector("span.item-title")).getText();
        assertEquals(resultadoEsperado, resultadoAtual);

        // Validar o preço
        assertEquals("R$ 79,99",driver.findElement(By.cssSelector("span.new-price")).getText());

        // Validar SUBTOTAL
        assertEquals("SUBTOTAL R$ 79,99",driver.findElement(By.cssSelector("div.subtotal")).getText());

        // Validar parcelas
        assertTrue(driver.findElement(By.cssSelector("div.ou-parcele")).getText().contains("ou em 12 x de R$ 8,03"));


    }

    @Test
    public void consultarMantis() throws InterruptedException {
        driver.get(url);
        driver.findElement(By.cssSelector("a.cc-btn.cc-dismiss")).click();
        driver.findElement(By.id("searchtext")).sendKeys("Mantis"); // Digita Testlink
        //Thread.sleep(2000);
        //driver.findElement(By.id("searchtext")).sendKeys(Keys.chord("Testlink")); // Soletra Testlink
        driver.findElement(By.id("btn_form_search")).click(); // Clica na lupa de pesquisa
        //Thread.sleep(2000);
        driver.findElement(By.cssSelector("span.comprar")).click(); // Clica no botão MATRICULE-SE

        // Validar nome do curso
        String resultadoEsperado = "Mantis";
        String resultadoAtual = driver.findElement(By.cssSelector("span.item-title")).getText();
        assertEquals(resultadoEsperado, resultadoAtual);

        // Validar o preço
        assertEquals("R$ 49,99",driver.findElement(By.cssSelector("span.new-price")).getText());

        // Validar SUBTOTAL
        assertEquals("SUBTOTAL R$ 49,99",driver.findElement(By.cssSelector("div.subtotal")).getText());

        // Validar parcelas
        assertTrue(driver.findElement(By.cssSelector("div.ou-parcele")).getText().contains("ou em 12 x de R$ 5,02"));


    }

}
